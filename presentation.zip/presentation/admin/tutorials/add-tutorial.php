<?php
session_start(); // start the session




// check if user is logged in as admin
if (!isset($_SESSION['user_type']) || ($_SESSION['user_type'] !== "admin" && $_SESSION['user_type'] !== "manager" && $_SESSION['user_type'] !== "coordinator")) {
    header("Location: index.html"); // redirect to login page if not logged in as admin
    exit();
}




// database details
$host = "localhost";
$username = "root";
$password = "";
$dbname = "week9";




// define variables and set to empty values
$user_name = $user_email = $user_type = $user_password = $user_type = "";
$user_name_err = $user_email_err = $user_password_err = $user_type_err = "";








// create connection
$conn = new mysqli($host, $username, $password, $dbname);




// check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}




// process form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // validate username
    if (empty(trim($_POST["username"]))) {
        $user_name_err = "Please enter a username.";
    } else {
        $user_name = trim($_POST["username"]);
    }




    // validate email
    if (empty(trim($_POST["email"]))) {
        $user_email_err = "Please enter an email.";
    } else {
        $user_email = trim($_POST["email"]);
    }
    // validate password
    if (empty(trim($_POST["password"]))) {
        $user_password_err = "Please enter a password.";
    } else {
        $user_password = trim($_POST["password"]);
    }
    // validate usertype
    if (empty(trim($_POST["userType"]))) {
        $user_type_err = "Please enter a user type.";
    } else {
        $user_type = trim($_POST["userType"]);
    }




    // check input errors before inserting into database
    if (empty($user_name_err) && empty($user_email_err) && empty($user_password_err) && empty($user_type_err)) {
        // prepare a insert statement
        $sql = "INSERT INTO users (user_name, user_email, user_type, user_password) VALUES (?, ?, ?, ?)";




        if ($stmt = $conn->prepare($sql)) {
            // bind parameters
            $stmt->bind_param("ssss", $param_user_name, $param_user_email, $param_user_type, $param_user_password);




            // set parameters
            $param_user_name = $user_name;
            $param_user_email = $user_email;
            $param_user_password = $user_password;
            $param_user_type = $user_type;




            // execute the statement
            if ($stmt->execute()) {
                // redirect to users.php
                header("Location: home.php");
                exit();
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }




            // close statement
            $stmt->close();
        }
    }




    // close connection
    $conn->close();
}
?>


