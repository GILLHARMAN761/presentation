<footer>
    <p>&copy; 2024 Gurdhian Singh | Student ID: 202107592</p>
    <a href="admin/login.php" class="admin-login-button">Admin Panel Login</a>
</footer>
